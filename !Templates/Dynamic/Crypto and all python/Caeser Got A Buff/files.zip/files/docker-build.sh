#!/bin/bash
docker build -t csl_aes:latest .